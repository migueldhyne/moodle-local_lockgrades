<?php
// Fichier : /local/lockgrades/index.php

require_once(__DIR__.'/../../config.php');
require_once($CFG->dirroot . '/local/lockgrades/form.php');

require_login();
// Seul un administrateur (ou un utilisateur ayant la capacité de configurer le site) peut accéder à ce plugin.
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/lockgrades/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('pluginname', 'local_lockgrades'));
$PAGE->set_heading(get_string('pluginname', 'local_lockgrades'));

$mform = new local_lockgrades_form();

echo $OUTPUT->header();

if ($mform->is_cancelled()){
    // Redirige vers la page de configuration en cas d'annulation
    redirect(new moodle_url('/admin/settings.php'));
} else if ($data = $mform->get_data()) {
    $idnumber = trim($data->idnumber);
    if (empty($idnumber)) {
         echo $OUTPUT->notification(get_string('error_noidnumber', 'local_lockgrades'));
    } else {
         // Utilisation d'une transaction pour garantir l'intégrité des mises à jour
         $transaction = $DB->start_delegated_transaction();
         if (!empty($data->lock)) {
              lock_grade_items_recursive($idnumber);
              $message = get_string('lock_success', 'local_lockgrades');
         } else if (!empty($data->unlock)) {
              unlock_grade_items_recursive($idnumber);
              $message = get_string('unlock_success', 'local_lockgrades');
         }
         $transaction->allow_commit();
         echo $OUTPUT->notification($message);
    }
}

$mform->display();
echo $OUTPUT->footer();

/**
 * Verrouille récursivement les éléments de grade pour la catégorie initiale et ses sous-catégories.
 *
 * @param string $idnumber L'identifiant de la catégorie initiale.
 */
function lock_grade_items_recursive($idnumber) {
    global $DB;
    $timestamp = time();
    
    // Étape 1 : Verrouiller l'élément initial et ses éléments associés
    $sql = "UPDATE {grade_items}
            SET locked = ?,
                timemodified = ?,
                locktime = ?
            WHERE iteminstance IN (SELECT iteminstance FROM {grade_items} WHERE idnumber = ?)
               OR categoryid IN (SELECT iteminstance FROM {grade_items} WHERE idnumber = ?)";
    $DB->execute($sql, array($timestamp, $timestamp, $timestamp, $idnumber, $idnumber));
    
    // Récupérer l'élément initial correspondant à l'idnumber fourni
    $gradeitem = $DB->get_record('grade_items', array('idnumber' => $idnumber));
    if (!$gradeitem) {
         return;
    }
    
    // Étape 2 : Récupérer les sous-catégories de l'élément initial
    $subcategories = $DB->get_records_sql("SELECT id FROM {grade_categories} WHERE parent = ?", array($gradeitem->iteminstance));
    if ($subcategories) {
         foreach ($subcategories as $subcategory) {
             // Étape 3 : Verrouiller les éléments de la sous-catégorie
             $sqlupdate = "UPDATE {grade_items}
                           SET locked = ?,
                               timemodified = ?,
                               locktime = ?
                           WHERE iteminstance = ? OR categoryid = ?";
             $DB->execute($sqlupdate, array($timestamp, $timestamp, $timestamp, $subcategory->id, $subcategory->id));
             
             // Étape 4 : Appel récursif pour traiter les sous-catégories imbriquées
             lock_subcategories_recursive($subcategory->id);
         }
    }
}

/**
 * Fonction récursive pour verrouiller les sous-catégories à partir d'un identifiant parent donné.
 *
 * @param int $parentid L'identifiant de la catégorie parente.
 */
function lock_subcategories_recursive($parentid) {
    global $DB;
    $timestamp = time();
    $sqlupdate = "UPDATE {grade_items}
                  SET locked = ?,
                      timemodified = ?,
                      locktime = ?
                  WHERE iteminstance = ? OR categoryid = ?";
    $DB->execute($sqlupdate, array($timestamp, $timestamp, $timestamp, $parentid, $parentid));

    // Récupérer les sous-catégories du parent actuel
    $subcategories = $DB->get_records_sql("SELECT id FROM {grade_categories} WHERE parent = ?", array($parentid));
    if ($subcategories) {
         foreach ($subcategories as $subcategory) {
             $DB->execute($sqlupdate, array($timestamp, $timestamp, $timestamp, $subcategory->id, $subcategory->id));
             lock_subcategories_recursive($subcategory->id);
         }
    }
}

/**
 * Déverrouille récursivement les éléments de grade pour la catégorie initiale et ses sous-catégories.
 *
 * @param string $idnumber L'identifiant de la catégorie initiale.
 */
function unlock_grade_items_recursive($idnumber) {
    global $DB;
    $timestamp = time();
    
    // Étape 1 : Déverrouiller l'élément initial et ses éléments associés en remettant locked et locktime à NULL
    $sql = "UPDATE {grade_items}
            SET locked = 0,
                timemodified = ?,
                locktime = 0
            WHERE iteminstance IN (SELECT iteminstance FROM {grade_items} WHERE idnumber = ?)
               OR categoryid IN (SELECT iteminstance FROM {grade_items} WHERE idnumber = ?)";
    $DB->execute($sql, array($timestamp, $idnumber, $idnumber));
    
    // Récupérer l'élément initial correspondant à l'idnumber fourni
    $gradeitem = $DB->get_record('grade_items', array('idnumber' => $idnumber));
    if (!$gradeitem) {
         return;
    }
    
    // Étape 2 : Récupérer les sous-catégories de l'élément initial
    $subcategories = $DB->get_records_sql("SELECT id FROM {grade_categories} WHERE parent = ?", array($gradeitem->iteminstance));
    if ($subcategories) {
         foreach ($subcategories as $subcategory) {
             // Étape 3 : Déverrouiller les éléments de la sous-catégorie
             $sqlupdate = "UPDATE {grade_items}
                           SET locked = 0,
                               timemodified = ?,
                               locktime = 0
                           WHERE iteminstance = ? OR categoryid = ?";
             $DB->execute($sqlupdate, array($timestamp, $subcategory->id, $subcategory->id));
             
             // Étape 4 : Appel récursif pour traiter les sous-catégories imbriquées
             unlock_subcategories_recursive($subcategory->id);
         }
    }
}

/**
 * Fonction récursive pour déverrouiller les sous-catégories à partir d'un identifiant parent donné.
 *
 * @param int $parentid L'identifiant de la catégorie parente.
 */
function unlock_subcategories_recursive($parentid) {
    global $DB;
    $timestamp = time();
    $sqlupdate = "UPDATE {grade_items}
                  SET locked = 0,
                      timemodified = ?,
                      locktime = 0
                  WHERE iteminstance = ? OR categoryid = ?";
    $DB->execute($sqlupdate, array($timestamp, $parentid, $parentid));
    
    // Récupérer les sous-catégories du parent actuel
    $subcategories = $DB->get_records_sql("SELECT id FROM {grade_categories} WHERE parent = ?", array($parentid));
    if ($subcategories) {
         foreach ($subcategories as $subcategory) {
             $DB->execute($sqlupdate, array($timestamp, $subcategory->id, $subcategory->id));
             unlock_subcategories_recursive($subcategory->id);
         }
    }
}
