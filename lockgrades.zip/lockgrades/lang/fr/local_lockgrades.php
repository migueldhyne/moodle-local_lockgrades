<?php
$string['pluginname']    = 'Lock Grades';
$string['idnumber']      = 'Identifiant de la catégorie';
$string['lockgrades']    = 'Verrouiller les évaluations';
$string['error_noidnumber'] = 'Veuillez saisir un identifiant valide.';
$string['lock_success']  = 'Les évaluations ont été verrouillées avec succès.';
$string['unlockgrades']   = 'Déverrouiller les évaluations';
$string['unlock_success'] = 'Les évaluations ont été déverrouillées avec succès.';