<?php
$string['pluginname']    = 'Lock Grades';
$string['idnumber']      = 'ID of categories';
$string['lockgrades']    = 'Lock grades';
$string['error_noidnumber'] = 'Insert a valid ID';
$string['lock_success']  = 'Lock successfull';
$string['unlockgrades']   = 'Unlock grades';
$string['unlock_success'] = 'Unlock successful';