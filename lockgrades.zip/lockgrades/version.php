<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025032400;       // La version du plugin (AAAAMMJJXX)
$plugin->requires  = 2018120300;       // Version minimale de Moodle requise.
$plugin->component = 'local_lockgrades';
