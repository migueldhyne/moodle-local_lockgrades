<?php
require_once("$CFG->libdir/formslib.php");

class local_lockgrades_form extends moodleform {
    public function definition() {
         $mform = $this->_form;
         
         // Champ de saisie pour l'idnumber
         $mform->addElement('text', 'idnumber', get_string('idnumber', 'local_lockgrades'));
         $mform->setType('idnumber', PARAM_TEXT);
         $mform->addRule('idnumber', null, 'required', null, 'client');
         
         // Boutons d'action : un pour verrouiller et un pour déverrouiller
         $mform->addElement('submit', 'lock', get_string('lockgrades', 'local_lockgrades'));
         $mform->addElement('submit', 'unlock', get_string('unlockgrades', 'local_lockgrades'));
    }
}
